package com.example.mylogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtUser, txtLogin;
    Button btnUser, btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUser = (EditText)findViewById(R.id.editTextTextPersonName);
        txtLogin = (EditText)findViewById(R.id.editTextTextPassword);

        btnUser = (Button)findViewById(R.id.button);
        btnUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String A_USER = txtUser.getText().toString();
                String A_PASS = txtLogin.getText().toString();
                if (A_USER.equals("Darwin") && A_PASS.equals("180960")){

                    Intent intent=new Intent(getApplicationContext(), MainActivity1.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Usuario o Contraseña Invalidos", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnLogin = (Button)findViewById(R.id.button2);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtUser.getText().clear();
               txtLogin.getText().clear();
            }
        });
    }
}
